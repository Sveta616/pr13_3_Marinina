﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Абитуриент
{
    class Abuturient
    {
        public Abuturient(string name, string surname,string otc,string ex)
        {
            this.name = name;
            this.surname = surname;
            this.otc = otc;
            this.ex = ex;
         
        }
        private string name;
        private string surname;
        private string otc;
        private string ex;

        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetSurname(string surname)
        {
            this.surname = surname;
        }
        public string GetSurname()
        {
            return this.surname;
        }
        public void SetOtc(string otc)
        {
            this.otc = otc;
        }
        public string GetOtc()
        {
            return this.otc;
        }
        public void SetEx(string ex)
        {
            this.ex= ex;
        }
        public string GetEx()
        {
            return this.ex;
        }
   

    }
}

