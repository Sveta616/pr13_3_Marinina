﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Абитуриент
{
    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private DataGridViewColumn dataGridViewColumn4 = null;

        private Queue<Abuturient> list = new Queue<Abuturient>();
        private DataGridViewColumn GetDataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Имя";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn GetDataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name = "";
                dataGridViewColumn2.HeaderText = "Фамилия";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn GetDataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "Отчество";
                dataGridViewColumn3.ValueType = typeof(string);
                dataGridViewColumn3.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn3;
        }
        private DataGridViewColumn GetDataGridViewColumn4()
        {
            if (dataGridViewColumn4 == null)
            {
                dataGridViewColumn4 = new DataGridViewTextBoxColumn();
                dataGridViewColumn4.Name = "";
                dataGridViewColumn4.HeaderText = "Экзамен по предмету";
                dataGridViewColumn4.ValueType = typeof(string);
                dataGridViewColumn4.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn4;
        }
    
        private void InitDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(GetDataGridViewColumn1());
            dataGridView1.Columns.Add(GetDataGridViewColumn2());
            dataGridView1.Columns.Add(GetDataGridViewColumn3());
            dataGridView1.Columns.Add(GetDataGridViewColumn4());
      
            dataGridView1.AutoResizeColumns();
        }
        private void ShowListInGrid()
        {
            dataGridView1.Rows.Clear();

            foreach (Abuturient s in list)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();

                cell1.ValueType = typeof(string);
                cell1.Value = s.GetName();
                cell2.ValueType = typeof(string);
                cell2.Value = s.GetSurname();
                cell3.ValueType = typeof(string);
                cell3.Value = s.GetOtc();
                cell4.ValueType = typeof(string);
                cell4.Value = s.GetEx();
          
            
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
 
                dataGridView1.Rows.Add(row);
            }
        }


        public Form1()
        {
            InitializeComponent();
            InitDataGridView();
        }
        private void addAb(string name, string surname, string otc, string ex)
        {
          
            int k = 0;
            foreach (Abuturient a in list)
            {
                if (a.GetName() == name && a.GetSurname() == surname && a.GetOtc() == otc)
                    k++;
            }

            if (k == 0)
            {
                Abuturient ab = new Abuturient(name, surname, otc, ex);
                list.Enqueue(ab);
                ShowListInGrid();
            }
            else MessageBox.Show("Такой абитуриент уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text==""||textBox2.Text==""||textBox3.Text=="")
            {
                MessageBox.Show("Заполните поле");
            }
            else
                addAb(textBox1.Text, textBox2.Text,textBox3.Text,comboBox1.Text);
                textBox1.Text = "";
                textBox2.Text = "";
            textBox3.Text = "";
          






        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int b = dataGridView1.CurrentRow.Index;
            dataGridView1.Rows[b].Cells[0].Value = textBox1.Text;
            dataGridView1.Rows[b].Cells[1].Value = textBox2.Text;
            dataGridView1.Rows[b].Cells[2].Value = textBox3.Text;
            dataGridView1.Rows[b].Cells[3].Value = comboBox1.Text;
  

        }

        private void сортироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
